WINTER CPL SKIN
***************
All trademarks and logos are owned by the CPL, and you may not copy them in any manner. The United States Patent and Trademark Office has granted the CPL a ten year exclusive registration for the following three marks: Cyberathlete� (Reg. No. 2,407,453), Cyberathlete Professional League� (Reg. No. 2,407,450) and CPL� (Reg. No. 2,397,115). 
***************

Skin created by: M|S-tetrik
Email: tetrik@clanmis.com
IRC: #M|S (gamesnet)

************
INSTALLATION
************
1) Point the winZIP installer to C:\Program Files\Steam\Skins\
2) Extract
3) Open up the Settings menu in Steam
4) Choose the 'Skin' tab and select CPL_skin from the drop-down box
5) Exit and restart steam
6) Happy using... or usage... or whatever


-tetrik